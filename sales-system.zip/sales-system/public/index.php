<?php

use Illuminate\Contracts\Http\Kernel;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Laravel - A PHP Framework For Web Artisans
|--------------------------------------------------------------------------
|
| Laravel is a web application framework with expressive, elegant syntax.
| We believe development must be an enjoyable and creative experience to
| be truly fulfilling. Laravel takes the pain out of development by
| easing common tasks used in the majority of web projects.
|
*/

define('LARAVEL_START', microtime(true));

require __DIR__.'/../vendor/autoload.php';

$app = require_once __DIR__.'/../bootstrap/app.php';

$kernel = $app->make(Kernel::class);

$response = $kernel->handle(
    $request = Request::capture()
)->send();

$kernel->terminate($request, $response);