<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;

class DashboardController extends Controller
{
    /**
     * Display the dashboard with summary statistics.
     */
    public function index()
    {
        $productCount = Product::count();
        $orderCount = Order::count();
        $userCount = User::count();
        $salesTotal = Order::where('status', 'completed')->sum('total_price');

        return view('dashboard', [
            'productCount' => $productCount,
            'orderCount' => $orderCount,
            'userCount' => $userCount,
            'salesTotal' => $salesTotal,
        ]);
    }
}