<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    /**
     * Display a listing of orders.
     */
    public function index()
    {
        // If user is admin show all orders else only user's orders
        $query = Order::with('user')->orderBy('created_at', 'desc');
        if (!Auth::user()->isAdmin()) {
            $query->where('user_id', Auth::id());
        }
        $orders = $query->paginate(10);
        return view('orders.index', ['orders' => $orders]);
    }

    /**
     * Show the form for creating a new order.
     */
    public function create()
    {
        $products = Product::where('stock', '>', 0)->get();
        return view('orders.create', ['products' => $products]);
    }

    /**
     * Store a newly created order in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'items' => ['required', 'array'],
        ]);

        $items = $request->input('items');
        if (empty($items)) {
            return back()->withErrors(['items' => 'Please select at least one product.']);
        }

        DB::beginTransaction();
        try {
            $total = 0;
            $orderItems = [];
            foreach ($items as $productId => $quantity) {
                $product = Product::findOrFail($productId);
                $qty = max(1, (int) $quantity);
                if ($qty > $product->stock) {
                    throw new \Exception("Not enough stock for {$product->name}");
                }
                $price = $product->price * $qty;
                $total += $price;
                $orderItems[] = [
                    'product_id' => $product->id,
                    'quantity' => $qty,
                    'price' => $product->price,
                ];
                // Update product stock
                $product->stock -= $qty;
                $product->save();
            }

            // Generate order number
            $orderNumber = 'ORD-' . now()->format('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(2)));

            // Create order
            $order = Order::create([
                'user_id' => Auth::id(),
                'order_number' => $orderNumber,
                'total_price' => $total,
                'status' => 'pending',
            ]);

            // Create order items
            foreach ($orderItems as $itemData) {
                $order->items()->create($itemData);
            }

            DB::commit();
            return redirect()->route('orders.show', $order->id)
                ->with('success', 'Order created successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified order.
     */
    public function show(Order $order)
    {
        // Authorize: admin or owner
        if (!Auth::user()->isAdmin() && $order->user_id !== Auth::id()) {
            abort(403);
        }
        $order->load(['items.product', 'user']);
        return view('orders.show', ['order' => $order]);
    }

    /**
     * Show the form for editing the order status.
     */
    public function edit(Order $order)
    {
        // Only admin can change order status
        if (!Auth::user()->isAdmin()) {
            abort(403);
        }
        return view('orders.edit', ['order' => $order]);
    }

    /**
     * Update the specified order in storage.
     */
    public function update(Request $request, Order $order)
    {
        if (!Auth::user()->isAdmin()) {
            abort(403);
        }
        $data = $request->validate([
            'status' => ['required', 'string'],
        ]);
        $order->update($data);
        return redirect()->route('orders.index')->with('success', 'Order status updated.');
    }

    /**
     * Remove the specified order from storage.
     */
    public function destroy(Order $order)
    {
        if (!Auth::user()->isAdmin()) {
            abort(403);
        }
        $order->delete();
        return redirect()->route('orders.index')->with('success', 'Order deleted successfully.');
    }
}