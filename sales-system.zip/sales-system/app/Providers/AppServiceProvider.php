<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // You may bind services into the container here
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Place any bootstrapping here
    }
}