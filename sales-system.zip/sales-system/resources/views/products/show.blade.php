@extends('layouts.app')

@section('title', 'Product Details')

@section('content')
    <h1 class="mb-4">Product Details</h1>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">{{ $product->name }}</h5>
            <h6 class="card-subtitle mb-2 text-muted">ID: {{ $product->id }}</h6>
            <p class="card-text">{{ $product->description }}</p>
            <p class="card-text"><strong>Price:</strong> ${{ number_format($product->price, 2) }}</p>
            <p class="card-text"><strong>Stock:</strong> {{ $product->stock }}</p>
            <a href="{{ route('products.edit', $product) }}" class="btn btn-warning">Edit</a>
            <a href="{{ route('products.index') }}" class="btn btn-secondary">Back to list</a>
        </div>
    </div>
@endsection