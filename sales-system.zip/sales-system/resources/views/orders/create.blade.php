@extends('layouts.app')

@section('title', 'Create Order')

@section('content')
    <h1 class="mb-4">Create Order</h1>
    <form method="POST" action="{{ route('orders.store') }}">
        @csrf
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                @forelse($products as $product)
                    <tr>
                        <td>{{ $product->name }}</td>
                        <td>${{ number_format($product->price, 2) }}</td>
                        <td>{{ $product->stock }}</td>
                        <td>
                            <input type="number" name="items[{{ $product->id }}]" min="0" max="{{ $product->stock }}" class="form-control" value="0">
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="text-center">No products available.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
        <button type="submit" class="btn btn-primary">Place Order</button>
        <a href="{{ route('orders.index') }}" class="btn btn-secondary">Back</a>
    </form>
@endsection