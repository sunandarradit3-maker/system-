@extends('layouts.app')

@section('title', 'Order Details')

@section('content')
    <h1 class="mb-4">Order Details</h1>
    <div class="mb-3">
        <strong>Order Number:</strong> {{ $order->order_number }}<br>
        <strong>User:</strong> {{ $order->user->name }}<br>
        <strong>Status:</strong> {{ ucfirst($order->status) }}<br>
        <strong>Date:</strong> {{ $order->created_at->format('Y-m-d H:i') }}
    </div>
    <h4>Items</h4>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            @foreach($order->items as $item)
                <tr>
                    <td>{{ $item->product->name }}</td>
                    <td>{{ $item->quantity }}</td>
                    <td>${{ number_format($item->price, 2) }}</td>
                    <td>${{ number_format($item->price * $item->quantity, 2) }}</td>
                </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr>
                <th colspan="3" class="text-end">Total</th>
                <th>${{ number_format($order->total_price, 2) }}</th>
            </tr>
        </tfoot>
    </table>
    <a href="{{ route('orders.index') }}" class="btn btn-secondary">Back to list</a>
@endsection